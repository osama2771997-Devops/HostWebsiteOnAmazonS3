NEXTWORK LOCAL WEBSITE

1. Extract this ZIP file to a folder.
2. Keep index.html beside the folder named "NextWork - Everyone should be in a job they love_files".
3. Double-click index.html to open it in Chrome.

The downloaded page uses local CSS, JavaScript, fonts and image assets. Some live services (analytics, reCAPTCHA, video files, and the original waitlist submission endpoint) may still require an internet connection and may not behave exactly like the hosted website.
